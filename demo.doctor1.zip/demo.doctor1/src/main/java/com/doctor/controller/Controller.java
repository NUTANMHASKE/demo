package com.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.doctor.entity.Doctor;
import com.doctor.service.Service_doctor;

@RestController
public class Controller {

	@Autowired
	Service_doctor s;
	@GetMapping("/get")
	public List<Doctor> get()
	{
		return s.getdoctorsData();
	}
	
	@PostMapping("/insert")
	public String insert(@RequestBody Doctor d)
	{
		return s.insertdoc(d);
	}
}
