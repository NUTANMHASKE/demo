package com.doctor.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.doctor.entity.Doctor;

@Repository
public class Dao_doctor {

	@Autowired
	SessionFactory sf;

	public List<Doctor> getdoctorsData() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Doctor.class);
		return criteria.list();

	}

	public String insertdoc(Doctor doc) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doc);
		transaction.commit();
		session.close();
		return "doctors inserted successfully";
	}

	public String updatedoctor(Doctor doc) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(doc);
		transaction.commit();
		session.close();
		return "doctors details completed";
	}

	public String deletedoctorBYID(int id) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = session.load(Doctor.class, id);
		session.delete(doctor);
		transaction.commit();
		session.close();
		return "doctor id deleted successfully";
	}

	public List<String> getdoctorsname() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Doctor.class);
		List<Doctor> ll = criteria.list();
		List<String> list = new ArrayList<>();
		for (Doctor doctor : ll) {
			list.add(doctor.getName());

		}
		return list;

	}
}