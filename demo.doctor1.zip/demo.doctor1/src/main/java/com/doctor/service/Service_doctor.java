package com.doctor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.dao.Dao_doctor;
import com.doctor.entity.Doctor;

@Service
public class Service_doctor {

	@Autowired
	Dao_doctor dd;

	
	public List<Doctor> getdoctorsData() {
		dd.getdoctorsData();
		return dd.getdoctorsData();
	}

	public String insertdoc(Doctor doc) {
		String msg = dd.insertdoc(doc);
		return msg;
	}

	public String updatedoctor(Doctor doc) {
		String msg = dd.updatedoctor(doc);
		return msg;
	}

	public String deletedoctorBYID(int id) {
		String msg = dd.deletedoctorBYID(id);
		return msg;
	}

	public List<String> getdoctorname() {
		List<String> list = dd.getdoctorsname();
		return list;
	}

}
