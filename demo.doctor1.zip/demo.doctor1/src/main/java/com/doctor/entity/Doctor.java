package com.doctor.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Doctor {

	int id;
	String name;
	String degree;
	double fees;
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "doctor [id=" + id + ", name=" + name + ", degree=" + degree + ", fees=" + fees + "]";
	}
	
	

}

